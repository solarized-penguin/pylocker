CREATE FUNCTION polygon(circle) RETURNS polygon
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
select pg_catalog.polygon(12, $1)
$$;

COMMENT ON FUNCTION polygon(circle) IS 'convert circle to 12-vertex polygon';

ALTER FUNCTION polygon(circle) OWNER TO postgres;

