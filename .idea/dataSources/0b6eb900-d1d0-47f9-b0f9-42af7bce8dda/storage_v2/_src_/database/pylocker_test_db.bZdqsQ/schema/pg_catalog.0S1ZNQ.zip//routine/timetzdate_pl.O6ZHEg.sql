CREATE FUNCTION timetzdate_pl(time with time zone, date) RETURNS timestamp with time zone
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
select ($2 + $1)
$$;

COMMENT ON FUNCTION timetzdate_pl(time WITH TIME ZONE, date) IS 'implementation of + operator';

ALTER FUNCTION timetzdate_pl(time WITH TIME ZONE, date) OWNER TO postgres;

