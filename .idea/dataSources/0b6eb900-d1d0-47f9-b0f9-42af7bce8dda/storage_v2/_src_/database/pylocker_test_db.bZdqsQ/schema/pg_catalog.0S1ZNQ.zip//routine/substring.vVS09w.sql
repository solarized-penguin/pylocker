CREATE FUNCTION substring(text, text, text) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
select pg_catalog.substring($1, pg_catalog.similar_to_escape($2, $3))
$$;

COMMENT ON FUNCTION substring(text, text, text) IS 'extract text matching SQL regular expression';

ALTER FUNCTION substring(text, text, text) OWNER TO postgres;

