CREATE VIEW user_mappings(authorization_identifier, foreign_server_catalog, foreign_server_name) AS
SELECT _pg_user_mappings.authorization_identifier,
       _pg_user_mappings.foreign_server_catalog,
       _pg_user_mappings.foreign_server_name
FROM information_schema._pg_user_mappings;

ALTER TABLE user_mappings
    OWNER TO postgres;

