CREATE FUNCTION _pg_expandarray(anyarray, OUT x anyelement, OUT n integer) RETURNS SETOF record
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
select $1[s], s - pg_catalog.array_lower($1,1) + 1
        from pg_catalog.generate_series(pg_catalog.array_lower($1,1),
                                        pg_catalog.array_upper($1,1),
                                        1) as g(s)
$$;

ALTER FUNCTION _pg_expandarray(anyarray, OUT anyelement, OUT integer) OWNER TO postgres;

