CREATE FUNCTION log(numeric) RETURNS numeric
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
select pg_catalog.log(10, $1)
$$;

COMMENT ON FUNCTION log(numeric) IS 'base 10 logarithm';

ALTER FUNCTION log(numeric) OWNER TO postgres;

