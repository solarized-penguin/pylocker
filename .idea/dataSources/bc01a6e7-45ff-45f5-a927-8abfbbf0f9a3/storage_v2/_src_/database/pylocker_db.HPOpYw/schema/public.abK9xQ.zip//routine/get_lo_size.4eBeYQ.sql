CREATE FUNCTION get_lo_size(loid integer) RETURNS bigint
    LANGUAGE plpgsql
AS
$$
DECLARE
        file_descriptor INTEGER;
        file_size BIGINT;
    BEGIN
        -- Open large object for reading.
        -- Parameter "x'40000'" is equivalent to postgres large object mode "INV_READ"
        -- which is necessary for method to work
        file_descriptor := lo_open(CAST(loid AS OID), x'40000' :: INT);
    
        -- Seek to the end
        -- "Seek" command = "2"
        PERFORM lo_lseek64(file_descriptor, 0, 2);
    
        -- Fetch current file position - location of the last byte
        file_size := lo_tell64(file_descriptor);
    
        -- Close open file.
        PERFORM lo_close(file_descriptor);
    
        RETURN file_size;
    END;
$$;

ALTER FUNCTION get_lo_size(integer) OWNER TO postgres;

